export const baseHeaders = {
  'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
}